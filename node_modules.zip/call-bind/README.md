# call-bind
Robustly `.call.bind()` a function.
